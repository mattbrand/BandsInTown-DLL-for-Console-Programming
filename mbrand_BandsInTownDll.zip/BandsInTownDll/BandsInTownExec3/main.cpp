#include <iostream>
#include <string>

#include "BandsInTownDll.h"

int main()
{
	BandsInTownDll::MyBandEntry myBandFinder;

	myBandFinder.FindShow( "Rubblebucket" );

	std::cin.get();

	return 1;
}