#pragma once

#include <string>

namespace BandsInTownDll
{
	class BandEntry
	{
	public:
		BandEntry( const std::string dateTime, const std::string venue, const std::string location, const std::string ticketStatus );
		BandEntry::BandEntry( const char* entry );
		~BandEntry() {};

		std::string parseForString( const char* entry, char* searchString, int quoteCount );

		std::string getDateTime() { return mDateTime; }
		std::string getVenue() { return mVenue; }
		std::string getLocation() { return mLocation; }
		std::string getTicketStatus() { return mTicketStatus; }
		bool getValid() { return mValid; }

	private:
		std::string mDateTime;
		std::string mVenue;
		std::string mLocation;
		std::string mTicketStatus;
		bool mValid;
	};
}