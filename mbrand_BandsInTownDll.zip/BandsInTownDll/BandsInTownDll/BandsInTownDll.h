#pragma once

#include <string>

namespace BandsInTownDll
{
    class MyBandEntry
    {
    public:
		static __declspec(dllexport) std::string FindShow( std::string bandName );
    };
}