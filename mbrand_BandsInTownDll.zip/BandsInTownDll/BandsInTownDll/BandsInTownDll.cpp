#include "BandsInTownDll.h"
#include "BandEntry.h"

#include <stdexcept>
#include <string>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <vcclr.h>
using namespace std;

#using <mscorlib.dll>

using namespace System;
using namespace System::IO;

#using <System.dll>
using namespace System::Net;

namespace BandsInTownDll
{
	std::string MyBandEntry::FindShow( std::string bandName )
	{
		std::string returnString;

		char* receiveCharStrings[20];
		int index = 0;

		System::Net::HttpWebRequest^ myRequest = dynamic_cast<HttpWebRequest^>( WebRequest::Create( "http://api.bandsintown.com/artists/Rubblebucket/events/search.json?api_version=2.0&app_id=54631&location=Burlington,VT&radius=150" ) );
		System::Net::WebResponse^ myResponse = myRequest->GetResponse();
		System::IO::Stream^ myReceiveStream = myResponse->GetResponseStream();
		System::Text::Encoding^ encode = System::Text::Encoding::GetEncoding( "utf-8" );

		// Pipe the stream to a higher level stream reader with the required encoding format.
		System::IO::StreamReader^ myReadStream = gcnew System::IO::StreamReader( myReceiveStream, encode );
		array<Char>^ read = gcnew array<Char>( 256 );

		// Read 256 charcters at a time.
		int count = myReadStream->Read( read, 0, 256 );

		while ( count > 0 )
		{
			// Dump the 256 characters on a string and display the string onto the console.
			String^ str = gcnew String( read, 0, count );
	   
			pin_ptr<const wchar_t> wch = PtrToStringChars(str);
			size_t convertedChars = 0;
			size_t  sizeInBytes = ((str->Length + 1) * 2);
			errno_t err = 0;
			char* charString = (char*)malloc(sizeInBytes);
			err = wcstombs_s(&convertedChars, charString, sizeInBytes, wch, sizeInBytes);
	
			receiveCharStrings[index] = charString;
			index++;
	
			count = myReadStream->Read( read, 0, 256 );
		}

		char entryBuffer[2048];
		int bufferIndex = 0;

		int tmpIndex = 0;
		int i = 0;
		bool done = false;
		while( tmpIndex<index && !done )
		{
			if( receiveCharStrings[tmpIndex][i] == '\n' )
			{
				done = true;
			}
			else
			{
				if( receiveCharStrings[tmpIndex][i] != '\0' )
				{
					entryBuffer[bufferIndex] = receiveCharStrings[tmpIndex][i];
					entryBuffer[bufferIndex + 1] = '\0';
					bufferIndex++;
					i++;
				}
				else
				{
					tmpIndex++;
					i = 0;
				}
			}
		}

		BandEntry myBandEntry( entryBuffer );

		if( myBandEntry.getDateTime() != "" )
		{
			returnString.append( myBandEntry.getDateTime() );
			returnString.append( " --- " );
			returnString.append( myBandEntry.getVenue() );
			returnString.append( " --- " );
			returnString.append( myBandEntry.getLocation() );
			returnString.append( " --- " );
			returnString.append( myBandEntry.getTicketStatus() );
		}
		else
			returnString.append( "There were no results." );

		cout << returnString << "\n";

		myReceiveStream->Close();
		myReadStream->Close();
		myResponse->Close();

		return returnString;
	}
}