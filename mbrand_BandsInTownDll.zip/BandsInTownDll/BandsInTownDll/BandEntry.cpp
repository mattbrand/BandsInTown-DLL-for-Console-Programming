#include "BandEntry.h"
#include <iostream>

namespace BandsInTownDll
{BandEntry::BandEntry( const char* entry )
	{
		mValid = false;
		mDateTime = parseForString( entry, "formatted_datetime", 1 );
		mVenue = parseForString( entry, "city", 5 );
		mLocation = parseForString( entry, "formatted_location", 1 );
		mTicketStatus = parseForString( entry, "ticket_status", 1 );

		if( mDateTime != "" && mLocation != "" && mTicketStatus != "" )
			mValid = true;
	}

	std::string BandEntry::parseForString( const char* entry, char* searchArray, int quoteCount )
	{
		std::string returnString = "";

		int index = 0;
		int strIndex = 0;
		bool matchStarted = false;
		bool found = false;

		while( index < (int)strlen( entry ) && !found )
		{
			if( matchStarted )
			{
				if( entry[index] == searchArray[strIndex] )
				{
					strIndex++;
					if( strIndex == strlen( searchArray ) )
						found = true;
				}
				else
				{
					matchStarted = false;
					strIndex = 0;
				}
			}
			else
			{
				if( entry[index] == searchArray[0] )
				{
					matchStarted = true;
					strIndex++;
				}
			}
			index++;
		}

		int quoteIndex = 0;
		if( found )
		{
			index += 3;

			while( quoteIndex < quoteCount )
			{
				if( quoteIndex == ( quoteCount - 1 ) && entry[index] != '"' )
					returnString.append( 1, entry[index] );
				if( entry[index] == '"' )
					quoteIndex++;
				index++;
			}
		}

		return returnString;
	}

}